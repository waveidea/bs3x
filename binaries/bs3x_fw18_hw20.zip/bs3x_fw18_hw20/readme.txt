BITSTREAM 3X FIRMWARE
*********************

- Before upgrading your firmware, save your current assignments into a library using the configuration software.

>> Upload both global/realtime parameters as well as assignments from the Bitstream 3X

- Upgrade your firmware using the firmware upgrader software

- Perform a reset to factory default (EDIT + OK + GROUP buttons while switching ON the Bitstream 3X)

- If required, download both global/realtime parameters as well as assignments (previously saved) to the Bitstream 3X

WaveIdea
